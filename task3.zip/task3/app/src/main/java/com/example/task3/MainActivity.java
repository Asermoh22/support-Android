package com.example.task3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView welctv;
    TextView cottv;
    TextView email;
    TextView pass;
    TextView forget;
    Button login;
    Button signup2;
    EditText enteremail;
    EditText enterpass;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        welctv = findViewById(R.id.weltv);
        cottv = findViewById(R.id.contv);
        email = findViewById(R.id.emaitv);
        pass = findViewById(R.id.passtv);
        forget = findViewById(R.id.FORGETTV);
        login = findViewById(R.id.buttob1BTN);
        signup2 = findViewById(R.id.button2BTN);
        enteremail = findViewById(R.id.emailEDT);
        enterpass = findViewById(R.id.passwordEDT);


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

              login();

            }
        });

        signup2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(MainActivity.this,signup.class);
                startActivity(in);
            }
        });


    }


    public void login() {
        String emailk = enteremail.getText().toString();
        String passm = enterpass.getText().toString();
        if (emailk.length() <= 0) {
            Toast.makeText(this, "please insert your email", Toast.LENGTH_SHORT).show();

        } else {
            if (passm.length() <= 0) {
                Toast.makeText(this, "please insert your password", Toast.LENGTH_SHORT).show();

            } else {
                Intent in = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(in);
            }
        }


    }
}
