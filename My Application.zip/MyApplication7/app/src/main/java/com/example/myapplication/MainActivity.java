package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
     RecyclerView rec;
    Adapter adapter;
    List<DataSet> filmsData =  new ArrayList<DataSet>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        adapter = new Adapter(filmsData);
        dataset();
        rec=findViewById(R.id.recl);
        rec.setAdapter(adapter);
        rec.setLayoutManager(new LinearLayoutManager(this));



    }
    public void dataset(){

        String[] checkBox11 = {
                "you",
                "ahmed",
                "aser",
                "akram",
                "amgad",
                "kariem",
                "maged",
                "nabil",
                "mostafa",

        };
        for (int i = 0; i < filmsData.size(); i++) {
            filmsData.add(new DataSet(checkBox11[i]));
        }
    }
}