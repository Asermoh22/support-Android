package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.viewholder> {
    List<DataSet> films;
    public Adapter(List<DataSet> films)
    {

        this.films = films;

    }
    @NonNull
    @Override
    public viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View ViewItem = LayoutInflater.from(parent.getContext()).inflate(R.layout.grocerieslist, parent, false);
        return new viewholder(ViewItem);
    }

    @Override
    public void onBindViewHolder(@NonNull viewholder holder, int position) {
    holder.box.setText(films.get(position).getCheckBox1());
    }

    @Override
    public int getItemCount() {
        return films.size();
    }

    public class viewholder extends RecyclerView.ViewHolder {
        TextView box;
        public viewholder(@NonNull View itemView) {
            super(itemView);
            box=itemView.findViewById(R.id.brandTV);
        }
    }
}
