package com.example.myapplication;

import android.widget.CheckBox;

public class DataSet {
    String checkBox1;

    public DataSet() {
    }

    public DataSet(String checkBox1) {
        this.checkBox1 = checkBox1;
    }

    public String getCheckBox1() {
        return checkBox1;
    }
}
